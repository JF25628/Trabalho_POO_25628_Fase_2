﻿/*
 * trabalhoPOO_25628
 * Nome: João Miguel Oliveira Figueiredo 
 * Numero de aluno: 25628
 * Email: a25628alunos.ipca.pt
 * Escola de tecnologia
 * Curso de Licenciatura de Engenharia de Sistemas Informaticos
 * Disciplina: Programação Orientada a Objetos
 * 07/11/2023
 * 
 */

        #region ESTADO

        #endregion

        #region COMPORTAMENTO

        #region CONSTRUTORES

        #endregion

        #region PROPRIEDADES

        #endregion

        #region OPERADORES
        
        #endregion

        #region OVERRIDES

        #endregion

        #region OUTROSMETODOS

        #endregion

        #region DESTRUCTOR

        #endregion

        #endregion

    }
}
